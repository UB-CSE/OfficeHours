package model

object Configuration {

  val DEV_MODE = true

}
